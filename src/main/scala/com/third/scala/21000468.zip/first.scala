package com.third.scala

object first {

  def reverseString(input: String): String = {
    if (input.isEmpty) {
      ""
    } else {
      reverseString(input.tail) + input.head
    }
  }

  def main(args: Array[String]): Unit = {

    val str = "123456789!"
    val reversedStr = reverseString(str)
    println(reversedStr)

  }
}
