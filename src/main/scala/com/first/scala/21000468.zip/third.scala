package com.first.scala

object third {
  def main(args: Array[String]) {
    val pi = 3.14159
    val radius = 5

    val volume = (4.0 / 3.0) * pi *radius * radius * radius;
    println(volume)

  }
}
