package com.first.scala

object second {
  def main(args: Array[String]) {
    val celsius = 35
    val fahrenheit = celsius * 1.8 + 32

    println(fahrenheit)

  }
}
