package com.first.scala

object myFirst {
  def main(args: Array[String]) {
    val pi = 3.14159
    val radius = 5

    val area = pi * radius * radius
    println(area)
  }
}
